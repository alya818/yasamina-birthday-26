
document.addEventListener("DOMContentLoaded", () => {
  document.querySelector('.container').classList.add('fade');
});
